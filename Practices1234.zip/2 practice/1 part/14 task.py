import math
x = 2
y = 1
z = 3
A = math.pow(math.log1p(x), 3) + math.exp(2 * x) / (x + 3.4) - 1/math.tan(3 / x * y * z)
print("Answer is: " + format(A))
