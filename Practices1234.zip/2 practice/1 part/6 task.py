import math
x = 3
y = 5
A = (math.sqrt(math.fabs(y))) + (math.pow(math.atan(math.log1p(x)), 3)) / (math.pow(x, y) - y + 1)
print("Answer is: " + format(A))
