import math
x = 1
y = 4
z = 3
A = math.pow(4, x * y) - math.pow(x, y * z) + math.pow(x * y, z)
print("Answer is: " + format(A))
