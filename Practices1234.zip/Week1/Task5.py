import math
number = int(input('Enter the value: '))
Step1 = number * 5
Step2 = Step1 + 8
Step3 = Step2 * 2
print('your new number is: ', Step3)
