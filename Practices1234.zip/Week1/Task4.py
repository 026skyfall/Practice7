import math
A = int(input('Enter the value: '))
Y1 = (A*A)/3
Y2 = ((A*A)+4)/6
Y3 = math.sqrt((A*A)+4)/4
Y4 = math.sqrt(((A*A)+4)*((A*A)+4)*((A*A)+4))/4
Y = Y1+Y2+Y3+Y4
print(Y)

