import math
a = int(input('Please enter the first wall: '))
b = int(input('Please enter the second wall: '))
c = int(input('Please enter the third wall: '))
p = a + b + c
S = math.sqrt(p*(p-a)*(p-b)*(p-c))
print(S)



