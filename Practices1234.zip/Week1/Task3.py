DecNum = 97.35
frac = DecNum - round(DecNum)
NewNum = (frac*100) + (round(DecNum)/100)
print(round(DecNum))
print(frac)
print(NewNum)





