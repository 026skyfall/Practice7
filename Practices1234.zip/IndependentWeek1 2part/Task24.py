i = 34
j = 67
while i < j:
    i += 2
    print(i)
    if i == 66:
        break

