num1 = int(input('Enter the value: '))
num2 = int(input('Enter the value: '))
if num2 != 0:
    result = num1/num2
else:
    result = 0

    print(result)


