Value = 14
print(Value > 10 and Value != 12)
if Value <= 15 and Value == 18:
    print("True")