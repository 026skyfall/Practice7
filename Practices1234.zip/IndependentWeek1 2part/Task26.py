n = 1
for n in range(1, 50):
    print(n, end=' ')
for n in range(51, 99):
    print(n, end=' ')
for n in range(100, 101):
    print(n, end=' ')

