a = 1
b = 7
c = 10
while a <= c:
    a += 1
    print(a)
    if a >= b:
      break
      


