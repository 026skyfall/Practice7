
n = int(input("enter the numb: "))
print("The Octal representation of", n, "is " + oct(n))
