a = int(input("enter 1st side:\n"))
b = int(input("enter 2nd side:\n"))
A = (a * b)
print("area =", A)